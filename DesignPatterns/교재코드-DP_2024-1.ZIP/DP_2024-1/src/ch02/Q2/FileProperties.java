package ch02.Q2;
// FileProperties 클래스를 구현해 보세요.