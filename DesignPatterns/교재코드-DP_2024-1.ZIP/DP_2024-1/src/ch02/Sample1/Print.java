package ch02.Sample1;

public interface Print {
    public abstract void printWeak();
    public abstract void printStrong();
}
