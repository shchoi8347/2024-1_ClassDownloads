package ch04.Sample.framework;

public abstract class Product {
    public abstract void use();
}
