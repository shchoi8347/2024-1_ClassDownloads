package ch12.Q1;

// UpDownBorder 클래스를 구현해 보세요.
