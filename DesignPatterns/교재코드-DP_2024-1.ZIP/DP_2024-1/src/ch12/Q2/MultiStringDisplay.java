package ch12.Q2;

// MultiStringDisplay 클래스를 구현해 보세요.
