package ch13.A1;

public interface Element {
    public abstract void accept(Visitor v);
}
