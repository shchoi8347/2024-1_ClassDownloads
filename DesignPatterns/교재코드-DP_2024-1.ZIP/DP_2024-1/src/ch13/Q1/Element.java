package ch13.Q1;

public interface Element {
    public abstract void accept(Visitor v);
}
