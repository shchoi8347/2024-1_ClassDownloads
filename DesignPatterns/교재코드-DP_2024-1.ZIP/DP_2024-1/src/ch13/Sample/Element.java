package ch13.Sample;

public interface Element {
    public abstract void accept(Visitor v);
}
