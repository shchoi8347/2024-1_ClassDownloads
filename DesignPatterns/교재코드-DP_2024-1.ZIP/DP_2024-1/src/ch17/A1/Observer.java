package ch17.A1;

public interface Observer {
    public abstract void update(NumberGenerator generator);
}
