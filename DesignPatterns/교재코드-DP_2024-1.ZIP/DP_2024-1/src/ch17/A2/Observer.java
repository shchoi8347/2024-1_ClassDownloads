package ch17.A2;

public interface Observer {
    public abstract void update(NumberGenerator generator);
}
