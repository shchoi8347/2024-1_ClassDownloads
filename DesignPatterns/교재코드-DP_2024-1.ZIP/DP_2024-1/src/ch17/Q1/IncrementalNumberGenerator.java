package ch17.Q1;

// IncrementalNumberGenerator 클래스를 구현하세요
