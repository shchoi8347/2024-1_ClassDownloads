package ch17.Q1;

public interface Observer {
    public abstract void update(NumberGenerator generator);
}
