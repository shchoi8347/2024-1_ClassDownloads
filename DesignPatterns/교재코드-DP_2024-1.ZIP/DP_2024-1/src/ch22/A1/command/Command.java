package ch22.A1.command;

public interface Command {
    public abstract void execute();
}
