package ch22.A2.command;

public interface Command {
    public abstract void execute();
}
