package ch22.A3.command;

public interface Command {
    public abstract void execute();
}
