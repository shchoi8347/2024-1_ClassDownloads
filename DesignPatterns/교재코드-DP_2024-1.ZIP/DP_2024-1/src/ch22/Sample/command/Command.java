package ch22.Sample.command;

public interface Command {
    public abstract void execute();
}
