package ch23.A1.language;

public interface Executor {
    public abstract void execute();
}
