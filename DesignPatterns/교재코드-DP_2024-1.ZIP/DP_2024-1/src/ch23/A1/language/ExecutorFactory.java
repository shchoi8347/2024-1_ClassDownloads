package ch23.A1.language;

public interface ExecutorFactory {
    public abstract Executor createExecutor(String name);
}
