package ch23.A1.language;

public class ParseException extends Exception {
    public ParseException(String msg) {
        super(msg);
    }
}
