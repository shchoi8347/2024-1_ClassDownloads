package ch23.Sample;

public class ParseException extends Exception {
    public ParseException(String msg) {
        super(msg);
    }
}
